"""月见八千代管理插件 — FUSHI 提醒 + AI 友人"""
import asyncio
import time
from pathlib import Path

from astrbot.api.star import Star, Context
from astrbot.api.event import filter, AstrMessageEvent, MessageEventResult, MessageChain
from astrbot.api import logger
from astrbot.api.event.filter import on_llm_request
from astrbot.core.provider.entities import ProviderRequest
from astrbot.core.agent.tool import ToolSet

from .utils.persona_builder import PersonaBuilder
from .utils.reminder_manager import ReminderManager
from .utils.platform_adapter import PlatformAdapter
from .utils.napcat_client import NapCatClient
from .utils.reminder_tools import (
    set_fushi_reminder, cancel_fushi_reminder, list_fushi_reminders
)
from .utils.life_os_tools import (
    record_expense, record_todo, record_idea, record_checkin,
    get_plan, get_dashboard, get_week_trend, get_debt, get_budget,
)
from .utils.life_os import LifeOSContext


class YachiyoManager(Star):
    def __init__(self, context: Context, config: dict = None):
        super().__init__(context)
        self.config = config or {}

        self.platform = PlatformAdapter(context)
        self.napcat = NapCatClient(
            api_url=self.config.get("napcat_api_url", "http://localhost:3000"),
            api_token=self.config.get("napcat_api_token", "")
        )
        self.reminder_manager = ReminderManager(self)

        plugin_dir = Path(__file__).parent
        self.persona_builder = PersonaBuilder(
            persona_enabled=self.config.get("persona_enabled", True),
            plugin_dir=plugin_dir
        )
        self.life_os = LifeOSContext(self.config)

        self._user_cache: dict[str, dict] = {}
        self._whitelist: dict = None

        logger.info("八千代插件已初始化（含 Life OS 模块）")

    # ── 生命周期 ──

    async def initialize(self):
        self._whitelist = await self.get_kv_data("whitelist",
                                                  default={"qq": [], "wechat": []})
        await self._migrate_old_data()
        await self.reminder_manager.restore_all()
        logger.info("八千代插件激活完成")

    async def terminate(self):
        """插件卸载时取消所有待执行的提醒任务"""
        for task in list(self.reminder_manager.tasks.values()):
            task.cancel()
        self.reminder_manager.tasks.clear()
        logger.info("八千代插件已终止，所有提醒任务已取消")
        await self.napcat.close()

    async def _migrate_old_data(self):
        old_dir = Path("data/plugin_data/yachiyo_manager")
        migrated = False
        for fname, kv_key in [("whitelist.json", "whitelist"),
                               ("user_configs.json", "user_configs")]:
            path = old_dir / fname
            if not path.exists():
                continue
            try:
                import json
                data = json.loads(path.read_text(encoding="utf-8"))
                existing = await self.get_kv_data(kv_key, default=None)
                if existing is None:
                    if fname == "whitelist.json":
                        data = {"qq": data.get("qq_whitelist", []),
                                "wechat": data.get("wechat_whitelist", [])}
                    await self.put_kv_data(kv_key, data)
                    migrated = True
                    logger.info(f"已迁移 {fname} → KV Store")
            except Exception as e:
                logger.warning(f"迁移 {fname} 失败: {e}")
        if migrated:
            logger.info("旧数据迁移完成")

    # ── 提醒创建（共享逻辑，命令通道和 LLM 工具复用）──

    async def _create_reminder_internal(self, event: AstrMessageEvent,
                                         delay_minutes: int, message: str,
                                         alert_type: str) -> dict:
        """创建提醒的核心逻辑。验证 + 创建 + 更新状态。
        返回 {"ok": bool, "error": str, ...}
        """
        if not (1 <= delay_minutes <= 1440):
            return {"ok": False, "error": "提醒时间需在 1-1440 分钟之间哦~"}

        alert_type = alert_type or self.config.get("default_alert_type", "normal")
        if alert_type not in ("normal", "urgent"):
            alert_type = "normal"

        user_id = self._get_user_id(event)
        platform = self._detect_platform(event)
        umo = event.unified_msg_origin
        group_id = (self.platform.get_group_id(event)
                    if self.platform.is_group_message(event) else None)

        task_id = await self.reminder_manager.create(
            user_id=user_id, platform=platform,
            delay_seconds=delay_minutes * 60,
            message=message, alert_type=alert_type,
            umo=umo, group_id=group_id
        )
        await self._update_user_interaction(user_id)

        return {"ok": True, "task_id": task_id, "user_id": user_id,
                "delay_minutes": delay_minutes, "message": message,
                "alert_type": alert_type}

    # ── 角色灵魂注入 ──

    @on_llm_request(priority=100)
    async def inject_persona(self, event: AstrMessageEvent, req: ProviderRequest):
        """LLM 请求前注入八千代角色上下文。追加模式。"""
        if not self.persona_builder.persona_enabled:
            return

        try:
            user_id = self._get_user_id(event)
            is_group = self.platform.is_group_message(event)

            if is_group and not self._is_at_or_command(event):
                return

            time_ctx = self._get_time_context()

            async def get_state():
                return await self._get_or_load_user_state(user_id)

            async def get_ltm():
                return await self._try_read_ltm(event)

            results = await asyncio.gather(
                get_state(), get_ltm(), return_exceptions=True
            )
            user_state = results[0] if not isinstance(results[0], Exception) else None
            ltm_ctx = results[1] if not isinstance(results[1], Exception) else ""

            prompt = self.persona_builder.assemble(
                user_state=user_state, time_ctx=time_ctx,
                ltm_ctx=ltm_ctx, is_group=is_group
            )

            req.system_prompt = (req.system_prompt or "") + "\n" + prompt
            req.system_prompt += self.life_os.build_context_block()

        except Exception as e:
            logger.error(f"Persona 注入失败: {e}")

    # ── 命令通道（0ms，不经过 LLM）──

    @filter.command("yachiyo_fushi_reminder")
    async def cmd_reminder(self, event: AstrMessageEvent,
                            delay_minutes: int = None, message: str = None,
                            alert_type: str = None) -> MessageEventResult:
        """设置 FUSHI 提醒"""
        if not await self._check_whitelist(event):
            yield event.plain_result("该功能仅对白名单用户开放哦~")
            return
        if not delay_minutes or not message:
            yield event.plain_result(
                "用法：/yachiyo_fushi_reminder <分钟> <内容> [normal|urgent]\n"
                "例如：/yachiyo_fushi_reminder 5 该喝水了 urgent"
            )
            return

        result = await self._create_reminder_internal(
            event, delay_minutes, message, alert_type
        )
        if result["ok"]:
            yield event.plain_result(
                f"收到啦~ FUSHI 会在 {delay_minutes} 分钟后叫你的哦♪"
            )
        else:
            yield event.plain_result(result["error"])

    @filter.command("yachiyo_cancel")
    async def cmd_cancel(self, event: AstrMessageEvent,
                          task_id: str = None) -> MessageEventResult:
        """取消提醒"""
        user_id = self._get_user_id(event)
        if not task_id:
            reminders = await self.reminder_manager.list_for_user(user_id)
            if not reminders:
                yield event.plain_result("当前没有待执行的提醒~")
                return
            lines = ["用法：/yachiyo_cancel <任务ID>"]
            for r in reminders:
                lines.append(f"  {r['task_id'][:16]}... → {r['message']}")
            yield event.plain_result("\n".join(lines))
            return
        reminders = await self.reminder_manager.list_for_user(user_id)
        matched = [r for r in reminders if r["task_id"].startswith(task_id)]
        if not matched:
            yield event.plain_result("未找到匹配的提醒~")
            return
        for r in matched:
            await self.reminder_manager.cancel(r["task_id"])
        yield event.plain_result(f"已取消 {len(matched)} 个提醒~")

    @filter.command("yachiyo_whitelist_add")
    async def cmd_wl_add(self, event: AstrMessageEvent,
                          qq_id: str = None) -> MessageEventResult:
        if not qq_id:
            yield event.plain_result("请提供 QQ ID")
            return
        wl = self._whitelist or {"qq": [], "wechat": []}
        qq_id_str = str(qq_id)
        if qq_id_str not in wl["qq"]:
            wl["qq"].append(qq_id_str)
            await self.put_kv_data("whitelist", wl)
            self._whitelist = wl
            yield event.plain_result(f"已将 {qq_id_str} 加入白名单♪")
        else:
            yield event.plain_result("该账号已在白名单中~")

    @filter.command("yachiyo_whitelist_remove")
    async def cmd_wl_remove(self, event: AstrMessageEvent,
                             qq_id: str = None) -> MessageEventResult:
        if not qq_id:
            yield event.plain_result("请提供 QQ ID")
            return
        wl = self._whitelist or {"qq": [], "wechat": []}
        qq_id_str = str(qq_id)
        if qq_id_str in wl["qq"]:
            wl["qq"].remove(qq_id_str)
            await self.put_kv_data("whitelist", wl)
            self._whitelist = wl
            yield event.plain_result(f"已将 {qq_id_str} 从白名单移除")
        else:
            yield event.plain_result("该账号不在白名单中~")

    @filter.command("yachiyo_whitelist_status")
    async def cmd_wl_status(self, event: AstrMessageEvent) -> MessageEventResult:
        wl = self._whitelist or {"qq": [], "wechat": []}
        qq_list = wl.get("qq", [])
        yield event.plain_result(
            f"QQ 白名单 {len(qq_list)} 人：{', '.join(qq_list)}" if qq_list
            else "白名单为空"
        )

    @filter.command("yachiyo")
    async def cmd_chat(self, event: AstrMessageEvent, *,
                        message: str = None) -> MessageEventResult:
        """自然语言对话入口"""
        if not message:
            yield event.plain_result("用 /yachiyo <消息> 和八千代聊天吧♪")
            return
        if not await self._check_whitelist(event):
            yield event.plain_result("该功能仅对白名单用户开放哦~")
            return

        prov_id = await self.context.get_current_chat_provider_id(
            event.unified_msg_origin
        )
        if not prov_id:
            yield event.plain_result("八千代暂时无法思考...请确认 LLM 已配置")
            return

        try:
            tools = ToolSet([
                set_fushi_reminder, cancel_fushi_reminder, list_fushi_reminders,
                record_expense, record_todo, record_idea, record_checkin,
                get_plan, get_dashboard, get_week_trend, get_debt, get_budget,
            ])
            resp = await self.context.tool_loop_agent(
                event=event, chat_provider_id=prov_id, prompt=message,
                tools=tools, max_steps=5, tool_call_timeout=30
            )
            if resp.completion_text:
                yield event.plain_result(resp.completion_text)
            else:
                yield event.plain_result("嗯...八千代走神了，再说一次好吗？")
        except Exception as e:
            logger.error(f"LLM 调用失败: {e}")
            yield event.plain_result(
                "八千代思考有点卡住了...请用 /yachiyo_fushi_reminder 来设置提醒♪"
            )

    # ── 提醒执行（确定性，不依赖 LLM）──

    async def _execute_reminder(self, payload: dict):
        """执行提醒：发送通知 + TTS。由 ReminderManager._run() 调用。"""
        message = payload.get("message", "")
        alert_type = payload.get("alert_type", "normal")
        umo = payload.get("umo", "")

        if alert_type == "normal":
            template = self.config.get("normal_message_template",
                                       "【FUSHI 闹钟】叮铃铃~ 神明大人，{message}")
            await self._send_text(umo, template.format(message=message))

        elif alert_type == "urgent":
            tts_sent = False
            group_id = payload.get("group_id")
            if payload.get("platform") == "qq" and group_id:
                try:
                    char = "yachiyo"
                    tts_text = f"神明大人！{message}！快醒醒！"
                    tts_sent = await self.napcat.send_group_ai_record(
                        character=char, group_id=group_id, text=tts_text
                    )
                except Exception as e:
                    logger.warning(f"TTS 失败: {e}")

            if not tts_sent:
                template = self.config.get("urgent_enhancement_template",
                                           "神明大人！{message}！快醒醒！")
                for i in range(3):
                    msg = template.format(message=message) + "！" * i
                    await self._send_text(umo, msg)
                    await asyncio.sleep(0.5)
                if payload.get("platform") == "qq" and group_id:
                    logger.info("TTS 发送失败，已 fallback 到文字")

    # ── 内部方法 ──

    def _get_user_id(self, event) -> str:
        return self.platform.get_user_id(event)

    def _detect_platform(self, event) -> str:
        return self.platform.detect_platform(event)

    def _get_time_context(self) -> str:
        import datetime
        h = datetime.datetime.now().hour
        if 5 <= h < 8:
            return "清晨。"
        if 8 <= h < 12:
            return "上午。"
        if 12 <= h < 14:
            return "中午。"
        if 14 <= h < 18:
            return "下午。"
        if 18 <= h < 22:
            return "傍晚。"
        if 22 <= h < 24:
            return "深夜，语气应更温柔关切。"
        return "凌晨，若用户未睡语气应关切。"

    def _is_at_or_command(self, event) -> bool:
        msg = event.message_str or ""
        return msg.startswith("/") or "@" in msg

    async def _check_whitelist(self, event) -> bool:
        platform = self._detect_platform(event)

        # 微信是个人账号，无需白名单
        if platform == "wechat":
            return True

        # QQ: 检查白名单
        user_id = self._get_user_id(event)
        if not user_id:
            return False
        if self.config.get("qq_whitelist_enabled", True):
            wl = self._whitelist or {"qq": [], "wechat": []}
            return user_id in [str(x) for x in wl.get("qq", [])]
        return True

    async def _get_or_load_user_state(self, user_id: str) -> dict:
        if user_id in self._user_cache:
            return self._user_cache[user_id]
        state = await self.get_kv_data(f"u_{user_id}", default=None)
        if state is None:
            state = {"first_seen": time.time(), "last_seen": time.time(),
                     "interaction_count": 0, "relationship": "stranger",
                     "mood": "neutral",
                     "nickname": "", "pinned_facts": []}
        self._user_cache[user_id] = state
        return state

    async def _save_user_state(self, user_id: str, state: dict):
        state["last_seen"] = time.time()
        self._user_cache[user_id] = state
        await self.put_kv_data(f"u_{user_id}", state)

    async def _update_user_interaction(self, user_id: str):
        s = await self._get_or_load_user_state(user_id)
        old_last_seen = s["last_seen"]
        s["interaction_count"] += 1
        s["last_seen"] = time.time()
        n = s["interaction_count"]
        if n >= 100:
            s["relationship"] = "intimate"
        elif n >= 30:
            s["relationship"] = "close"
        elif n >= 10:
            s["relationship"] = "familiar"
        elif n >= 3:
            s["relationship"] = "acquaintance"
        elapsed = time.time() - old_last_seen
        if s["relationship"] in ("intimate", "close") and elapsed > 86400 * 3:
            s["mood"] = "missing_you"
        elif elapsed > 86400 * 7:
            s["mood"] = "slightly_worried"
        else:
            s["mood"] = "happy"
        await self._save_user_state(user_id, s)

    async def _try_read_ltm(self, event) -> str:
        try:
            return event.get_extra("_ltm_context", "") or ""
        except Exception:
            return ""

    async def _send_text(self, umo: str, message: str):
        try:
            chain = MessageChain().message(message)
            await self.context.send_message(umo, chain)
        except Exception as e:
            logger.error(f"消息发送失败 [{umo}]: {e}")
