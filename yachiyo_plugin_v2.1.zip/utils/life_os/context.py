"""Life OS 上下文构建 — 为 LLM 注入当前生活数据状态"""
from datetime import datetime

from .file_ops import read_file, ensure_repo_path
from .dashboard import (
    extract_today_plan, extract_weekly_snapshot, extract_global_status,
    parse_weekly_log_table, compute_weekly_stats, extract_retest_date,
)
from .expense import (
    parse_expense_table, compute_today_totals, compute_monthly_totals,
    parse_debt_from_claude_md, MONTHLY_BUDGET,
)


class LifeOSContext:
    """读取 Futureplan 数据仓库，构建注入 LLM 的上下文块。"""

    def __init__(self, config: dict):
        self.config = config
        self._last_build = 0.0
        self._cached_block = ""

    def build_context_block(self) -> str:
        """构建追加到 system_prompt 的 Life OS 上下文。

        包含：当前时间、本周快照、今日餐饮、本月预算、复测日期、可用工具列表。
        """
        import time
        now = time.time()
        # 缓存 60 秒，避免同一轮多次调用重复读文件
        if self._cached_block and (now - self._last_build) < 60:
            return self._cached_block

        try:
            repo_path = ensure_repo_path(self.config)
        except FileNotFoundError:
            return ""

        dashboard_md = read_file(repo_path, "dashboard.md")
        finance_claude = read_file(repo_path, "finance/CLAUDE.md")
        expense_md = read_file(repo_path, "finance/expense-log.md")

        # 时间上下文
        now_dt = datetime.now()
        weekday_names = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
        time_str = now_dt.strftime(f"%Y年%m月%d日 {weekday_names[now_dt.weekday()]} %H:%M")

        lines = [
            "",
            "[Life OS 上下文]",
            f"当前时间：{time_str}",
        ]

        # 本周快照摘要
        if dashboard_md:
            log_rows = parse_weekly_log_table(dashboard_md)
            if log_rows:
                stats = compute_weekly_stats(log_rows)
                lines.append(
                    f"本周快照：创作 {stats['creative']} | "
                    f"脱离 {stats['detachment']} | "
                    f"L1 {stats['l1']}"
                )
                # 趋势
                for field, trend in stats.get("trends", {}).items():
                    labels = {"energy": "精力", "mood": "情绪", "anxiety": "焦虑"}
                    lines.append(f"  {labels.get(field, field)}趋势：{trend}")

            retest = extract_retest_date(dashboard_md)
            if retest:
                lines.append(f"下次复测：{retest}")

        # 今日餐饮
        if expense_md:
            entries = parse_expense_table(expense_md)
            today = compute_today_totals(entries)
            if today["entry_count"] > 0:
                over = " ⚠️ 已超标" if today["over_budget"] else ""
                lines.append(
                    f"今日餐饮累计：¥{today['today_dining']:.0f} / "
                    f"日均 ¥{today['daily_budget']}{over}"
                )

            month = compute_monthly_totals(entries)
            if month["entry_count"] > 0:
                lines.append(
                    f"本月预算剩余：¥{month['month_remaining']:.0f} / "
                    f"¥{MONTHLY_BUDGET}（已用 {month['budget_pct']}%）"
                )

        lines.append("")
        lines.append("可用 Life OS 工具：")
        lines.append("- 用户说花了钱/买了东西 → record_expense")
        lines.append("- 用户说要做/记得/别忘了 → record_todo")
        lines.append("- 用户说灵感/创意/设定/想法 → record_idea")
        lines.append("- 用户汇报精力/情绪/焦虑/状态 → record_checkin")
        lines.append("- 用户问计划/安排/今天做什么 → get_plan")
        lines.append("- 用户问本周情况/仪表盘 → get_dashboard")
        lines.append("- 用户问趋势/走势/状态变化 → get_week_trend")
        lines.append("- 用户问欠款/债务/还欠多少 → get_debt")
        lines.append("- 用户问花费/预算/花了多少 → get_budget")

        block = "\n".join(lines)
        self._cached_block = block
        self._last_build = now
        return block
