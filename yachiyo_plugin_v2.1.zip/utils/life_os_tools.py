"""Life OS LLM 工具 — 9 个 @filter.llm_tool 注册

写入类 4 个：record_expense, record_todo, record_idea, record_checkin
查询类 5 个：get_plan, get_dashboard, get_week_trend, get_debt, get_budget

工具不写角色台词，只返回结构化数据。LLM 根据数据选择语气做角色回复。
"""
import asyncio
import re
from datetime import datetime

from astrbot.api.event import filter, AstrMessageEvent, MessageEventResult
from astrbot.api import logger

from .life_os.file_ops import (
    ensure_repo_path, read_file, append_to_inbox, append_expense, sync_git,
)
from .life_os.expense import (
    parse_expense_table, compute_today_totals, compute_monthly_totals,
    parse_debt_from_claude_md, MONTHLY_BUDGET, DAILY_DINING_BUDGET,
)
from .life_os.checkin import format_checkin_line, validate_checkin_fields
from .life_os.dashboard import (
    extract_today_plan, extract_weekly_snapshot, extract_global_status,
    parse_weekly_log_table, compute_weekly_stats, extract_retest_date,
)


def _fire_sync(repo_path: str):
    """Fire-and-forget git 同步。"""
    try:
        loop = asyncio.get_event_loop()
        loop.create_task(sync_git(repo_path))
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════
#  写入类工具（4个）
# ═══════════════════════════════════════════════════════════

@filter.llm_tool(name="record_expense")
async def record_expense(self, event: AstrMessageEvent,
                         amount: float, description: str,
                         category: str = "其他") -> MessageEventResult:
    """记录一笔支出。当用户说花了钱/买了东西/付款/消费/吃饭/买/付了时调用。
    如果用户连续说了多笔支出（例如"午餐35，咖啡15"），对每一笔分别调用本工具。
    Args:
        amount(number): 金额（只填数字，不含¥符号。模糊金额取中间值，例如"三四十"→35）
        description(string): 买了什么，简短描述即可
        category(string): 分类：餐饮/交通/购物/娱乐/健康/副业成本/其他
    """
    try:
        repo_path = ensure_repo_path(self.config)
    except FileNotFoundError as e:
        yield event.plain_result(f"EXPENSE_ERROR|error=仓库路径不存在")
        return

    # 写入
    append_expense(repo_path, amount, category, description)

    # 读取更新后的统计
    expense_md = read_file(repo_path, "finance/expense-log.md")
    entries = parse_expense_table(expense_md)
    today = compute_today_totals(entries)

    # 返回结构化确认（LLM 根据 over_budget 等字段决定语气）
    yield event.plain_result(
        f"EXPENSE_OK|amount={amount}|desc={description}|category={category}|"
        f"today_dining={today['today_dining']:.0f}|daily_budget={DAILY_DINING_BUDGET}|"
        f"over_budget={'true' if today['over_budget'] else 'false'}|"
        f"budget_pct={today['budget_pct']}"
    )

    _fire_sync(repo_path)


@filter.llm_tool(name="record_todo")
async def record_todo(self, event: AstrMessageEvent,
                      content: str) -> MessageEventResult:
    """记录一个待办事项。当用户说要做/记得/别忘了/提醒我/我今天要/明天要/待办时调用。
    Args:
        content(string): 待办的具体内容
    """
    try:
        repo_path = ensure_repo_path(self.config)
    except FileNotFoundError:
        yield event.plain_result("TODO_ERROR|error=仓库路径不存在")
        return

    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    line = f"todo {content}  # {ts}"
    append_to_inbox(repo_path, line)

    yield event.plain_result(
        f"TODO_OK|content={content}|date={datetime.now().strftime('%Y-%m-%d')}"
    )

    _fire_sync(repo_path)


@filter.llm_tool(name="record_idea")
async def record_idea(self, event: AstrMessageEvent,
                      content: str) -> MessageEventResult:
    """记录一个灵感、创意或设定想法。当用户说出点子/构思/设计/角色设定/世界观/故事想法/创意时调用。
    保留用户的完整表达，不要自行总结或改写。
    Args:
        content(string): 灵感内容，保留用户的完整原始表达
    """
    try:
        repo_path = ensure_repo_path(self.config)
    except FileNotFoundError:
        yield event.plain_result("IDEA_ERROR|error=仓库路径不存在")
        return

    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    line = f"idea {content}  # {ts}"
    append_to_inbox(repo_path, line)

    yield event.plain_result(
        f"IDEA_OK|content_preview={content[:80]}|"
        f"date={datetime.now().strftime('%Y-%m-%d')}"
    )

    _fire_sync(repo_path)


@filter.llm_tool(name="record_checkin")
async def record_checkin(self, event: AstrMessageEvent,
                         energy: int, mood: int, anxiety: int,
                         creative: str, detachment: str, l1: str,
                         note: str = "") -> MessageEventResult:
    """记录每日汇报。当用户提到精力/情绪/焦虑/今天状态/汇报/今天怎么样时调用。
    如果用户没明确说某个数值，根据语气推断。'还行'=5，'累爆了'=2-3，'还不错'=6-7，
    '挺高的'=7-8。不确定时往中间靠（5）。完全无法推断的字段填-1表示缺失。
    如果用户给出范围（如"精力最多3"），取较低值。
    Args:
        energy(number): 精力 1-10（-1表示缺失，无法推断）
        mood(number): 情绪 1-10（-1表示缺失）
        anxiety(number): 焦虑 1-10（-1表示缺失）
        creative(string): 微创作 ✅或❌（用户没说就填❌）
        detachment(string): 心理脱离 ✅或❌（用户没说就填❌）
        l1(string): L1护肤 ✅或❌（用户没说就填❌）
        note(string): 备注，包含"最消耗的事"和"值得的事"
    """
    try:
        repo_path = ensure_repo_path(self.config)
    except FileNotFoundError:
        yield event.plain_result("CHECKIN_ERROR|error=仓库路径不存在")
        return

    line = format_checkin_line(energy, mood, anxiety,
                               creative, detachment, l1, note)
    append_to_inbox(repo_path, line)

    # 读取本周统计
    dashboard_md = read_file(repo_path, "dashboard.md")
    log_rows = parse_weekly_log_table(dashboard_md)
    stats = compute_weekly_stats(log_rows)

    yield event.plain_result(
        f"CHECKIN_OK|energy={energy}|mood={mood}|anxiety={anxiety}|"
        f"creative={creative}|detachment={detachment}|l1={l1}|"
        f"weekly_creative={stats['creative']}|weekly_detachment={stats['detachment']}|"
        f"weekly_l1={stats['l1']}|total_days={stats['total_days']}"
    )

    _fire_sync(repo_path)


# ═══════════════════════════════════════════════════════════
#  查询类工具（5个）
# ═══════════════════════════════════════════════════════════

@filter.llm_tool(name="get_plan")
async def get_plan(self, event: AstrMessageEvent) -> MessageEventResult:
    """获取今日计划。当用户询问今天做什么/有什么安排/今日计划/日程/今天干嘛时调用。"""
    try:
        repo_path = ensure_repo_path(self.config)
    except FileNotFoundError:
        yield event.plain_result("（找不到数据仓库，请联系神明大人检查配置~）")
        return

    dashboard_md = read_file(repo_path, "dashboard.md")
    plan = extract_today_plan(dashboard_md)

    if not plan or len(plan) < 20:
        yield event.plain_result("PLAN_EMPTY")
        return

    # 提取关键信息摘要
    date_match = re.search(r"日期[：:]\s*\*?\*?([^*\n]+)", plan)
    energy_match = re.search(r"精力预估[：:]\s*\*?\*?([^*\n]+)", plan)
    date_str = date_match.group(1).strip() if date_match else ""
    energy_str = energy_match.group(1).strip() if energy_match else ""

    yield event.plain_result(
        f"PLAN_OK|date={date_str}|energy={energy_str}\n"
        f"{plan}"
    )


@filter.llm_tool(name="get_dashboard")
async def get_dashboard(self, event: AstrMessageEvent) -> MessageEventResult:
    """获取本周仪表盘总览。当用户询问本周情况/这周怎么样/本周总结/仪表盘/最近状态时调用。"""
    try:
        repo_path = ensure_repo_path(self.config)
    except FileNotFoundError:
        yield event.plain_result("（找不到数据仓库~）")
        return

    dashboard_md = read_file(repo_path, "dashboard.md")
    if not dashboard_md:
        yield event.plain_result("DASHBOARD_EMPTY")
        return

    snapshot = extract_weekly_snapshot(dashboard_md)
    log_rows = parse_weekly_log_table(dashboard_md)
    stats = compute_weekly_stats(log_rows)
    global_status = extract_global_status(dashboard_md)
    retest = extract_retest_date(dashboard_md)

    # 构建结构化输出
    parts = ["DASHBOARD_OK"]
    parts.append(f"total_days={stats['total_days']}")
    parts.append(f"creative={stats['creative']}")
    parts.append(f"detachment={stats['detachment']}")
    parts.append(f"l1={stats['l1']}")
    if retest:
        parts.append(f"retest={retest}")
    parts.append("")
    parts.append("--- 本周快照 ---")
    parts.append(snapshot)
    parts.append("")
    parts.append("--- 本周日志 ---")
    for r in log_rows[-7:]:  # 最多显示7天
        parts.append(
            f"| {r['date']} | 精力{r.get('energy','')} | "
            f"情绪{r.get('mood','')} | 焦虑{r.get('anxiety','')} | "
            f"创作{r.get('creative','')} | 脱离{r.get('detachment','')} | "
            f"L1{r.get('l1','')} | {r.get('note','')}"
        )
    parts.append("")
    parts.append("--- 全局状态 ---")
    parts.append(global_status)

    yield event.plain_result("\n".join(parts))


@filter.llm_tool(name="get_week_trend")
async def get_week_trend(self, event: AstrMessageEvent) -> MessageEventResult:
    """获取本周趋势分析。当用户询问趋势/走势/最近状态变化/有没有变好/有没有变差时调用。"""
    try:
        repo_path = ensure_repo_path(self.config)
    except FileNotFoundError:
        yield event.plain_result("（找不到数据仓库~）")
        return

    dashboard_md = read_file(repo_path, "dashboard.md")
    log_rows = parse_weekly_log_table(dashboard_md)
    stats = compute_weekly_stats(log_rows)

    if not log_rows:
        yield event.plain_result("TREND_EMPTY|本周暂无数据")
        return

    # 构建趋势报告
    lines = [f"TREND_OK|total_days={stats['total_days']}"]
    lines.append("")

    # 各项趋势
    for field, trend in stats.get("trends", {}).items():
        labels = {"energy": "精力", "mood": "情绪", "anxiety": "焦虑"}
        label = labels.get(field, field)
        lines.append(f"  {label}：{trend}")

    # 每日明细（用于 LLM 判断具体变化）
    lines.append("")
    lines.append("每日明细：")
    for r in log_rows:
        lines.append(
            f"  {r['date']} 精力{r.get('energy','?')} "
            f"情绪{r.get('mood','?')} 焦虑{r.get('anxiety','?')} "
            f"创作{r.get('creative','?')} 脱离{r.get('detachment','?')} "
            f"L1{r.get('l1','?')}"
        )

    # 完成率
    lines.append("")
    lines.append(
        f"完成率：创作 {stats['creative']} | "
        f"脱离 {stats['detachment']} | "
        f"L1 {stats['l1']}"
    )

    yield event.plain_result("\n".join(lines))


@filter.llm_tool(name="get_debt")
async def get_debt(self, event: AstrMessageEvent) -> MessageEventResult:
    """获取债务总览。当用户询问欠款/债务/还欠多少/还款进度时调用。"""
    try:
        repo_path = ensure_repo_path(self.config)
    except FileNotFoundError:
        yield event.plain_result("（找不到数据仓库~）")
        return

    finance_claude = read_file(repo_path, "finance/CLAUDE.md")
    dashboard_md = read_file(repo_path, "dashboard.md")

    debts = parse_debt_from_claude_md(finance_claude)

    # 计算总金额
    total_debt = 0
    for d in debts:
        try:
            total_debt += int(re.sub(r'[^0-9]', '', d["amount"]))
        except (ValueError, KeyError):
            pass

    lines = [f"DEBT_OK|total_debt={total_debt}|items={len(debts)}"]
    lines.append("")
    lines.append("债务清单（按还款优先级）：")
    for i, d in enumerate(debts, 1):
        lines.append(
            f"  {i}. {d.get('creditor','?')} "
            f"¥{d.get('amount','?')} "
            f"利率{d.get('rate','?')} "
            f"— {d.get('strategy','?')}"
        )

    # 从 dashboard 提取里程碑进度
    if dashboard_md:
        m = re.search(
            r"💰\s*偿债\+储蓄.*?([\d,]+).*?([\d,]+)",
            dashboard_md
        )
        if m:
            lines.append(f"\n偿债+储蓄进度：{m.group(0).strip()}")

    yield event.plain_result("\n".join(lines))


@filter.llm_tool(name="get_budget")
async def get_budget(self, event: AstrMessageEvent) -> MessageEventResult:
    """获取本月预算使用情况。当用户询问花费/花了多少/还剩多少/预算/这个月花多少了时调用。"""
    try:
        repo_path = ensure_repo_path(self.config)
    except FileNotFoundError:
        yield event.plain_result("（找不到数据仓库~）")
        return

    expense_md = read_file(repo_path, "finance/expense-log.md")
    entries = parse_expense_table(expense_md)
    month = compute_monthly_totals(entries)
    today = compute_today_totals(entries)

    lines = [
        f"BUDGET_OK|month_spent={month['month_spent']:.0f}|"
        f"month_budget={MONTHLY_BUDGET}|"
        f"month_remaining={month['month_remaining']:.0f}|"
        f"budget_pct={month['budget_pct']}",
        f"today_dining={today['today_dining']:.0f}|"
        f"daily_budget={DAILY_DINING_BUDGET}|"
        f"over_budget={'true' if today['over_budget'] else 'false'}",
        "",
        f"本月支出：¥{month['month_spent']:.0f} / ¥{MONTHLY_BUDGET}（{month['budget_pct']}%）",
        f"本月剩余：¥{month['month_remaining']:.0f}",
    ]

    if month["by_category"]:
        lines.append("")
        lines.append("分类汇总：")
        for cat, amt in sorted(month["by_category"].items(),
                               key=lambda x: x[1], reverse=True):
            lines.append(f"  {cat}：¥{amt:.0f}")

    if today["entry_count"] > 0:
        over = " ⚠️ 已超标" if today["over_budget"] else ""
        lines.append(f"\n今日餐饮：¥{today['today_dining']:.0f} / ¥{DAILY_DINING_BUDGET}{over}")

    yield event.plain_result("\n".join(lines))
